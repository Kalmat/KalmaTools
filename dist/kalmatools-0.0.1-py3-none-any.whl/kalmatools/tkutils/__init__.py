#!/usr/bin/python
# -*- coding: utf-8 -*-

__version__ = "0.0.1"


from ._tkutils import (
    FakeRoot,
    Tooltip,
    tkLoadFont
)
