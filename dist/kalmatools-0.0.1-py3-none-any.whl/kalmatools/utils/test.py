import threading
import time
import traceback


class Timer:
    SNOOZE = 0
    ONEOFF = 1

    def __init__(self, timerType=SNOOZE):

        self._timerType = timerType
        self._keep = threading.Event()
        self._timerSnooze = None
        self._timerOneoff = None

    class _SnoozeTimer(threading.Timer):
        # This uses threading.Timer class, but consumes more CPU?!?!?!

        def __init__(self, event, msec, callback, *args):
            threading.Thread.__init__(self)

            self.stopped = event
            self.msec = msec
            self.callback = callback
            self.args = args

        def run(self):
            while not self.stopped.wait(self.msec):
                self.callback(*self.args)

    def start(self, msec: int, callback, *args, start_now=False) -> bool:

        started = False
        if msec > 0:
            if self._timerType == self.SNOOZE:
                if self._timerSnooze is None:
                    self._timerSnooze = self._SnoozeTimer(self._keep, msec / 1000, callback, *args)
                    self._timerSnooze.start()
                    if start_now:
                        callback(*args)
                    started = True
            else:
                if self._timerOneoff is None:
                    self._timerOneoff = threading.Timer(msec / 1000, callback, *args)
                    self._timerOneoff.start()
                    started = True
        return started

    def stop(self):
        if self._timerType == self.SNOOZE:
            self._keep.set()
            self._timerSnooze.join()
        else:
            self._timerOneoff.cancel()
            self._timerOneoff.join()

    def is_alive(self):
        if self._timerType == self.SNOOZE:
            isAlive = self._timerSnooze is not None and self._timerSnooze.is_alive() and not self._keep.is_set()
        else:
            isAlive = self._timerOneoff is not None and self._timerOneoff.is_alive()
        return isAlive

    isAlive = is_alive

KEEP = True

def callback():
    global KEEP
    KEEP = False
    print("ENDED", time.strftime("%M:%S"))

if __name__ == "__main__":
    count = 0
    t = Timer(timerType=Timer.ONEOFF)
    t.start(5000, callback)
    print("START", time.strftime("%M:%S"))
    while KEEP:
        if count % 10000000 == 0:
            print("STILL RUNNING")
        count += 1
